package com.example.covid;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.covid.R;
import com.example.covid.adapter.CovidAdapter;
import com.example.covid.data.rekapitulasi.ContentItem;
import com.example.covid.data.rekapitulasi.Data;
import com.example.covid.service.CovidApi;
import com.example.covid.service.CovidListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MainActivity<covid> extends AppCompatActivity {
    TextView tvName, tvNim, tvTitle, tvTitle2;
    private MenuItem item;
    private RecyclerView rvHome;
    private CovidAdapter covidAdapter;
    BottomNavigationView bottom_nav;


    private CovidListener<ArrayList<ContentItem>> listCovid = new CovidListener<ArrayList<ContentItem>>() {
        @Override
        public void onSuccess(ArrayList<ContentItem> body) {
            covidAdapter.setListCovid(body);
        }

        @Override
        public void onFailed(String message) {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();

        }
    };
    private Object CovidListener;

    @SuppressLint("NonConstantResourceId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            getSupportActionBar().setTitle("Kasus Covid");
            tvName = findViewById(R.id.tv_name);
            tvNim = findViewById(R.id.tv_nim);
            tvTitle = findViewById(R.id.tv_title);
            tvTitle2 = findViewById(R.id.tv_title2);
            rvHome = findViewById(R.id.rv_home);
            bottom_nav = findViewById(R.id.bottom_navigation);
            covidAdapter = new CovidAdapter(this);
            rvHome.setLayoutManager(new LinearLayoutManager(this));
            rvHome.setHasFixedSize(true);
            rvHome.setAdapter(covidAdapter);
            rvHome.setLayoutManager(new LinearLayoutManager(this));

            bottom_nav.setOnNavigationItemSelectedListener(item -> {
                Intent main, rs;
                switch (item.getItemId()) {
                    case R.id.btn_menu_main:
                    main = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(main);
                    finish();
                    break;
                    case R.id.btn_menu_rs:
                    rs = new Intent(MainActivity.this, RSActivity.class);
                    startActivity(rs);
                    finish();
                    break;
                }
                return true;
            });
            CovidApi covidApi = new CovidApi();
            covidApi.getListCovid(listCovid);
        }
}