package com.example.covid.data.wilayah;
import com.example.covid.data.rekapitulasi.Data;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class WilayahResponse implements Serializable{
	@SerializedName("statusCode")
	private int statusCode;

	@SerializedName("data")
	private Object data;

	public void setStatusCode(int statusCode){
		this.statusCode = statusCode;
	}

	public int getStatusCode(){
		return statusCode;
	}

	public void setData(Object data){
		this.data = data;
	}

	public Data getData(){
		return (Data) data;
	}

	@Override
 	public String toString(){
		return 
			"Response{" + 
			"status_code = '" + statusCode + '\'' + 
			",data = '" + data + '\'' + 
			"}";
		}
}
