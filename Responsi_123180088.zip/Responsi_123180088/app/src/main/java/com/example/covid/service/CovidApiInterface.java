package com.example.covid.service;

import com.example.covid.data.faskes.FaskesResponse;
import com.example.covid.data.rekapitulasi.Data;
import com.example.covid.data.rekapitulasi.RekapitulasiResponse;
import com.example.covid.data.wilayah.WilayahResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface CovidApiInterface {
//    String URL_BASE = "https://covid19-public.digitalservice.id/api/v1/";
//    @GET("/wilayah/jabar")
//    Call<WilayahResponse> getWilayah();

    @GET("rekapitulasi_v2/jabar/harian")
    Call<RekapitulasiResponse> getRekapitulasi();

    @GET("sebaran_v2/jabar/faskes")
    Call<FaskesResponse> getFaskes();

}
