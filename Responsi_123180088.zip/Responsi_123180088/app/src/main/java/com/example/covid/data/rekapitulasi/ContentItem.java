package com.example.covid.data.rekapitulasi;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class ContentItem implements Serializable {
	@SerializedName("suspectDiscarder")
	private int suspectDiscarded;

	@SerializedName("suspectMeninggalHarian")
	private int suspectMeninggalHarian;

	@SerializedName("closecontactDikarantina")
	private int closecontactDikarantina;

	@SerializedName("cONFIRMATION")
	private int cONFIRMATION;

	@SerializedName("suspectDiisolasi")
	private int suspectDiisolasi;

	@SerializedName("confirmationDiisolasi")
	private int confirmationDiisolasi;

	@SerializedName("closecontactMeninggalHarian")
	private int closecontactMeninggalHarian;

	@SerializedName("confirmationMeninggal")
	private int confirmationMeninggal;

	@SerializedName("probableMeninggal")
	private int probableMeninggal;

	@SerializedName("confirmationSelesai")
	private int confirmationSelesai;

	@SerializedName("closecontactDiscarded")
	private int closecontactDiscarded;

	@SerializedName("kodeProv")
	private String kodeProv;

	@SerializedName("namaProv")
	private String namaProv;

	@SerializedName("cLOSECONTACT")
	private int cLOSECONTACT;

	@SerializedName("probableDiscarded")
	private int probableDiscarded;

	@SerializedName("tanggal")
	private String tanggal;

	@SerializedName("probableDiisolasi")
	private int probableDiisolasi;

	@SerializedName("sUSPECT")
	private int sUSPECT;



	public void setSuspectDiscarded(int suspectDiscarded){
		this.suspectDiscarded = suspectDiscarded;
	}

	public int getSuspectDiscarded(){
		return suspectDiscarded;
	}

	public void setSuspectMeninggalHarian(int suspectMeninggalHarian){
		this.suspectMeninggalHarian = suspectMeninggalHarian;
	}

	public int getSuspectMeninggalHarian(){
		return suspectMeninggalHarian;
	}

	public void setClosecontactDikarantina(int closecontactDikarantina){
		this.closecontactDikarantina = closecontactDikarantina;
	}

	public int getClosecontactDikarantina(){
		return closecontactDikarantina;
	}

	public void setCONFIRMATION(int cONFIRMATION){
		this.cONFIRMATION = cONFIRMATION;
	}

	public int getCONFIRMATION(){
		return cONFIRMATION;
	}

	public void setSuspectDiisolasi(int suspectDiisolasi){
		this.suspectDiisolasi = suspectDiisolasi;
	}

	public int getSuspectDiisolasi(){
		return suspectDiisolasi;
	}

	public void setConfirmationDiisolasi(int confirmationDiisolasi){
		this.confirmationDiisolasi = confirmationDiisolasi;
	}

	public int getConfirmationDiisolasi(){
		return confirmationDiisolasi;
	}

	public void setClosecontactMeninggalHarian(int closecontactMeninggalHarian){
		this.closecontactMeninggalHarian = closecontactMeninggalHarian;
	}

	public int getClosecontactMeninggalHarian(){
		return closecontactMeninggalHarian;
	}

	public void setConfirmationMeninggal(int confirmationMeninggal){
		this.confirmationMeninggal = confirmationMeninggal;
	}

	public int getConfirmationMeninggal(){
		return confirmationMeninggal;
	}

	public void setProbableMeninggal(int probableMeninggal){
		this.probableMeninggal = probableMeninggal;
	}

	public int getProbableMeninggal(){
		return probableMeninggal;
	}

	public void setConfirmationSelesai(int confirmationSelesai){
		this.confirmationSelesai = confirmationSelesai;
	}

	public int getConfirmationSelesai(){
		return confirmationSelesai;
	}

	public void setClosecontactDiscarded(int closecontactDiscarded){
		this.closecontactDiscarded = closecontactDiscarded;
	}

	public int getClosecontactDiscarded(){
		return closecontactDiscarded;
	}

	public void setKodeProv(String kodeProv){
		this.kodeProv = kodeProv;
	}

	public String getKodeProv(){
		return kodeProv;
	}

	public void setNamaProv(String namaProv){
		this.namaProv = namaProv;
	}

	public String getNamaProv(){
		return namaProv;
	}

	public void setCLOSECONTACT(int cLOSECONTACT){
		this.cLOSECONTACT = cLOSECONTACT;
	}

	public int getCLOSECONTACT(){
		return cLOSECONTACT;
	}

	public void setProbableDiscarded(int probableDiscarded){
		this.probableDiscarded = probableDiscarded;
	}

	public int getProbableDiscarded(){
		return probableDiscarded;
	}

	public void setTanggal(String tanggal){
		this.tanggal = tanggal;
	}

	public String getTanggal(){
		return tanggal;
	}

	public void setProbableDiisolasi(int probableDiisolasi){
		this.probableDiisolasi = probableDiisolasi;
	}

	public int getProbableDiisolasi(){
		return probableDiisolasi;
	}

	public void setSUSPECT(int sUSPECT){
		this.sUSPECT = sUSPECT;
	}

	public int getSUSPECT(){
		return sUSPECT;
	}

	@Override
 	public String toString(){
		return 
			"ContentItem{" + 
			"suspect_discarded = '" + suspectDiscarded + '\'' + 
			",suspect_meninggal_harian = '" + suspectMeninggalHarian + '\'' + 
			",closecontact_dikarantina = '" + closecontactDikarantina + '\'' + 
			",cONFIRMATION = '" + cONFIRMATION + '\'' + 
			",suspect_diisolasi = '" + suspectDiisolasi + '\'' + 
			",confirmation_diisolasi = '" + confirmationDiisolasi + '\'' + 
			",closecontact_meninggal_harian = '" + closecontactMeninggalHarian + '\'' + 
			",confirmation_meninggal = '" + confirmationMeninggal + '\'' + 
			",probable_meninggal = '" + probableMeninggal + '\'' + 
			",confirmation_selesai = '" + confirmationSelesai + '\'' + 
			",closecontact_discarded = '" + closecontactDiscarded + '\'' + 
			",kode_prov = '" + kodeProv + '\'' + 
			",nama_prov = '" + namaProv + '\'' + 
			",cLOSECONTACT = '" + cLOSECONTACT + '\'' + 
			",probable_discarded = '" + probableDiscarded + '\'' + 
			",tanggal = '" + tanggal + '\'' + 
			",probable_diisolasi = '" + probableDiisolasi + '\'' + 
			",sUSPECT = '" + sUSPECT + '\'' + 
			"}";
		}

	public int getcLOSECONTACT() {
		return cLOSECONTACT;
	}

	public void setcLOSECONTACT(int cLOSECONTACT) {
		this.cLOSECONTACT = cLOSECONTACT;
	}



	public int getsUSPECT() {
		return sUSPECT;
	}

	public void setsUSPECT(int sUSPECT) {
		this.sUSPECT = sUSPECT;
	}



	public int getcONFIRMATION() {
		return cONFIRMATION;
	}

	public void setcONFIRMATION(int cONFIRMATION) {
		this.cONFIRMATION = cONFIRMATION;
	}


}
