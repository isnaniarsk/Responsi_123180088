package com.example.covid.service;
import android.util.Log;

import com.example.covid.data.faskes.DataItem;
import com.example.covid.data.faskes.FaskesResponse;
import com.example.covid.data.rekapitulasi.ContentItem;
import com.example.covid.data.rekapitulasi.RekapitulasiResponse;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CovidApi{
//    public static final String BASE_URL = "https://covid19-public.digitalservice.id/api/v1/";
//    private Retrofit retrofit = null;
    private Retrofit retrofit;
    public CovidApiInterface getCovidApi() {
        if(retrofit==null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl("https://covid19-public.digitalservice.id/api/v1/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }return retrofit.create(CovidApiInterface.class);
        }


//    CovidApiInterface getCovidApi() {
//        Log.d("insialisasi", "getHolidayApi: ");
//        if (retrofit == null) {
//            //membangun atau instansiasi data retrofit
//            retrofit = new Retrofit
//                    .Builder()
//                    .baseUrl(BASE_URL)
//                    .addConverterFactory(GsonConverterFactory.create())
//                    .build();
//        }
//        return retrofit.create(CovidApiInterface.class);
//    }

    public void getListCovid(final CovidListener<ArrayList<ContentItem>> listener){
        getCovidApi().getRekapitulasi().enqueue(new Callback<RekapitulasiResponse>() {
            @Override
            public void onResponse(@NotNull Call<RekapitulasiResponse> call, @NotNull Response<RekapitulasiResponse> response) {
                RekapitulasiResponse rekapitulasiResponse = response.body();
                if (response.isSuccessful() && response.body() != null){
                    assert rekapitulasiResponse != null;
                    listener.onSuccess(rekapitulasiResponse.getData().getContent());
                }
            }

            @Override
            public void onFailure(@NotNull Call<RekapitulasiResponse> call, Throwable t) {
                listener.onFailed(t.getMessage());
                Log.d("TAG",t.getMessage());
            }
        });
    }

//    public void getWilayah(final CovidListener<ArrayList<WilayahResponse>> listener){
//        getCovidApi().getWilayah().enqueue(new Callback<WilayahResponse>() {
//            @Override
//            public void onResponse(Call<WilayahResponse> call, Response<WilayahResponse> response) {
//                WilayahResponse wilayahResponse = response.body();
//                if (wilayahResponse != null && wilayahResponse.getData() != null){
//                    listener.onSuccess(wilayahResponse.getData().getContent();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<WilayahResponse> call, Throwable t) {
//                listener.onFailed(t.getMessage());
//                Log.d("TAG",t.getMessage());
//            }
//        });
//    }

    public void getListHospital(final CovidListener<ArrayList<DataItem>> listener){
        getCovidApi().getFaskes().enqueue(new Callback<FaskesResponse>() {
            @Override
            public void onResponse(Call<FaskesResponse> call, Response<FaskesResponse> response) {
                FaskesResponse faskesResponse = response.body();
                if (faskesResponse != null){
                    listener.onSuccess((ArrayList<DataItem>) faskesResponse.getData());
                }
            }

            @Override
            public void onFailure(Call<FaskesResponse> call, Throwable t) {
                listener.onFailed(t.getMessage());
            }
        });
    }

    private void onFailure(String message) {
    }
    private void onResponse(List<DataItem> data) {
    }

}

