package com.example.covid;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.covid.data.faskes.DataItem;
import com.example.covid.data.rekapitulasi.Data;
import com.example.covid.service.CovidApi;
import com.example.covid.service.CovidListener;
import com.example.covid.adapter.HospitalAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class RSActivity extends AppCompatActivity {

    private RecyclerView rvRs;
    private HospitalAdapter hospitalAdapter;
    BottomNavigationView bottom_nav;

    private CovidListener<ArrayList<DataItem>> listHospital = new CovidListener<ArrayList<DataItem>>(){

        @Override
        public void onSuccess(ArrayList<DataItem> body) { hospitalAdapter.setDataHospital(body); }

        @Override
        public void onFailed(String message) { Toast.makeText(RSActivity.this, message, Toast.LENGTH_SHORT).show();}
    };

    @Override
    protected void onCreate(Bundle savedInstaceState){
        super.onCreate(savedInstaceState);
        setContentView(R.layout.activity_rs);

        rvRs = findViewById(R.id.rv_rs);
        bottom_nav = findViewById(R.id.bottom_navigation);

        hospitalAdapter = new HospitalAdapter(this);

    }

}
