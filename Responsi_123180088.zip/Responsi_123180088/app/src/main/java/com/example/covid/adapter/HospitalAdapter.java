package com.example.covid.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.covid.R;
import com.example.covid.data.faskes.DataItem;

import java.util.ArrayList;

public class HospitalAdapter extends RecyclerView.Adapter<HospitalAdapter.ViewHolder>{
    protected Context context;
    public HospitalAdapter(Context context) {this.context = context; }
    private ArrayList<DataItem> listHospital = new ArrayList<>();

    public void setDataHospital(ArrayList<DataItem> dataItems){
        if (dataItems != null) {
            this.listHospital.clear();
            this.listHospital.addAll(dataItems);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_rs, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(listHospital.get(position));
        holder.btnMaps.setOnClickListener(v -> {
                    Uri gmmIntentUri = Uri.parse(
                            "geo:"+ listHospital.get(position).getLatitude() +
                                    "," + listHospital.get(position).getLongitude() +
                                    "?q="+listHospital.get(position).getNama());
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    context.startActivity(mapIntent);
                }
        );
    }

    @Override
    public int getItemCount() {
        return listHospital.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvName, tvAddress;
        private Button btnMaps;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_rs_name);
            tvAddress = itemView.findViewById(R.id.tv_rs_address);
            btnMaps = itemView.findViewById(R.id.btn_rs_maps);
        }

        public void bind(DataItem dataItem) {
            tvName.setText(dataItem.getNama());
            tvAddress.setText(dataItem.getAlamat());
        }
    }
}
