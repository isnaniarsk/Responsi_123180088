package com.example.covid.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.covid.R;
import com.example.covid.data.rekapitulasi.ContentItem;

import java.util.ArrayList;

public class CovidAdapter extends RecyclerView.Adapter<CovidAdapter.ViewHolder> {
    protected Context context;

    public CovidAdapter (Context context) {this.context = context;}
    private ArrayList<ContentItem> listCovid = new ArrayList<>();

    public void setListCovid(ArrayList<ContentItem> contentItems) {
        if(contentItems != null) {
            this.listCovid.clear();
            this.listCovid.addAll(contentItems);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CovidAdapter.ViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_item,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CovidAdapter.ViewHolder holder, int position) {
        holder.bind(listCovid.get(position));
    }

    @Override
    public int getItemCount() {
        return listCovid.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvDate, tvSembuh, tvMeninggal, tvTerkonfirmasi;

        public ViewHolder(@NonNull View itemView){
            super(itemView);
            tvDate = itemView.findViewById(R.id.tv_item_date);
            tvSembuh = itemView.findViewById(R.id.tv_item_sembuh);
            tvMeninggal = itemView.findViewById(R.id.tv_item_meninggal);
            tvTerkonfirmasi = itemView.findViewById(R.id.tv_item_terkonfirmasi);
        }
        public void bind(ContentItem contentItems) {
            tvDate.setText(contentItems.getTanggal());
            tvSembuh.setText(contentItems.getConfirmationSelesai());
            tvMeninggal.setText(contentItems.getConfirmationMeninggal());
            tvTerkonfirmasi.setText((contentItems.getCONFIRMATION()));
        }
    }
}
