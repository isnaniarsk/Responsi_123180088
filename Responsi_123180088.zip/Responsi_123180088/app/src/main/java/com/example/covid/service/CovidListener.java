package com.example.covid.service;

import com.example.covid.data.rekapitulasi.ContentItem;
import com.example.covid.data.rekapitulasi.Data;

import java.util.ArrayList;

public interface CovidListener <T> {
    void onSuccess(T body);
    void onFailed(String message);
}
