package com.example.covid.data.rekapitulasi;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Metadata implements Serializable{
	@SerializedName("lastUpdate")
	private Object lastUpdate;

	public void setLastUpdate(Object lastUpdate){
		this.lastUpdate = lastUpdate;
	}

	public Object getLastUpdate(){
		return lastUpdate;
	}

	@Override
 	public String toString(){
		return 
			"Metadata{" + 
			"last_update = '" + lastUpdate + '\'' + 
			"}";
		}
}
